//
//  FirstViewController.h
//  <%= AppName %>
//
//  Copyright (c) 2012 OrganizationName. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
<%- interfaceContent %>
@end
