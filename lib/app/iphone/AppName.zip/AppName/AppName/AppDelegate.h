//
//  AppDelegate.h
//  AppName
//
//  Created by Achal Aggarwal on 27/09/12.
//  Copyright (c) 2012 OrganizationName. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
