//
//  AppDelegate.h
//  <%= AppName %>
//
//  Copyright (c) 2012 OrganizationName. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
